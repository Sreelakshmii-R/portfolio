import { motion } from "framer-motion";
import { FaBriefcase, FaMapMarkerAlt, FaCalendarAlt } from "react-icons/fa";

export default function ProfessionalExperience() {
  return (
    <section
      id="experience"
      className="w-full py-24 bg-white"
    >
      <div className="w-full max-w-6xl mx-auto px-6">

        {/* SECTION HEADER */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <p className="uppercase tracking-[3px] text-[#00246B] font-semibold">
            Professional Experience
          </p>

          <h2 className="text-5xl font-bold mt-4 text-[#2E2E2E]">
            Experience
          </h2>

          <p className="text-gray-500 mt-5 max-w-2xl mx-auto text-lg">
            Practical experience building and improving web applications
            in a professional development environment.
          </p>
        </motion.div>

        {/* EXPERIENCE CARD */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          viewport={{ once: true }}
          className="mt-14 bg-[#F8FAFC] rounded-3xl border border-gray-100 shadow-sm p-8 md:p-10"
        >

          {/* TOP */}
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-6">

            <div className="flex gap-5">

              {/* ICON */}
              <div className="flex-shrink-0 w-14 h-14 rounded-2xl bg-[#EAF1FF] flex items-center justify-center">
                <FaBriefcase
                  size={24}
                  className="text-[#00246B]"
                />
              </div>

              {/* ROLE */}
              <div>
                <h3 className="text-2xl md:text-3xl font-bold text-[#2E2E2E]">
                  Software Development Intern
                </h3>

                <p className="text-lg font-semibold text-[#00246B] mt-2">
                  LSD Productions
                </p>
              </div>

            </div>

            {/* CURRENT BADGE */}
            <span className="self-start px-4 py-2 rounded-full bg-green-100 text-green-700 text-sm font-semibold">
              Currently Working
            </span>

          </div>

          {/* META */}
          <div className="flex flex-wrap gap-5 mt-7 text-gray-500">

            <div className="flex items-center gap-2">
              <FaCalendarAlt className="text-[#00246B]" />
              <span>Sep 2026 – Present</span>
            </div>

            <div className="flex items-center gap-2">
              <FaMapMarkerAlt className="text-[#00246B]" />
              <span>Kochi, Kerala</span>
            </div>

          </div>

          {/* DESCRIPTION */}
          <div className="mt-8">

            <p className="text-gray-600 leading-8 text-lg">
              Working as a Software Development Intern, contributing to
              website development and improvement tasks while gaining
              practical experience in a professional software environment.
            </p>

            {/* RESPONSIBILITIES */}
            <div className="mt-7">

              <h4 className="text-lg font-bold text-[#2E2E2E] mb-4">
                Key Contributions
              </h4>

              <ul className="space-y-3 text-gray-600">

                <li className="flex gap-3">
                  <span className="text-[#00246B] font-bold">•</span>
                  <span>
                    Developed and updated web pages based on project
                    requirements and design needs.
                  </span>
                </li>

                <li className="flex gap-3">
                  <span className="text-[#00246B] font-bold">•</span>
                  <span>
                    Contributed to the development and improvement of
                    the PoshESalon website.
                  </span>
                </li>

                <li className="flex gap-3">
                  <span className="text-[#00246B] font-bold">•</span>
                  <span>
                    Worked on updates and improvements to the LSD Productions
                    website.
                  </span>
                </li>

                <li className="flex gap-3">
                  <span className="text-[#00246B] font-bold">•</span>
                  <span>
                    Collaborated on website development tasks and adapted
                    implementations based on project requirements.
                  </span>
                </li>

              </ul>

            </div>

          </div>

          {/* TECH TAGS */}
          <div className="flex flex-wrap gap-3 mt-8">

            <span className="px-4 py-2 bg-white border border-gray-200 rounded-full text-sm font-medium text-gray-600">
              Web Development
            </span>

            <span className="px-4 py-2 bg-white border border-gray-200 rounded-full text-sm font-medium text-gray-600">
              UI Development
            </span>

            <span className="px-4 py-2 bg-white border border-gray-200 rounded-full text-sm font-medium text-gray-600">
              Website Development
            </span>

            <span className="px-4 py-2 bg-white border border-gray-200 rounded-full text-sm font-medium text-gray-600">
              AI-Assisted Development
            </span>

          </div>

        </motion.div>

      </div>
    </section>
  );
}